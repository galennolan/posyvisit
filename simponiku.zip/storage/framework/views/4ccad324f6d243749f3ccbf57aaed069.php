<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Edit Data Kunjungan Ibu Bersalin dan Nifas')); ?>

        </h2>
        <nav class="breadcrumb">
            <ol class="list-reset flex text-sm">
                <li><a href="/dashboard" class="text-blue-600 hover:text-blue-800">Home</a></li>
                <li><span class="mx-2">/</span></li>
                <li><a href="<?php echo e(route('kunjungan-ibu-bersalin.index')); ?>" class="text-blue-600 hover:text-blue-800">Kunjungan Ibu Bersalin dan Nifas</a></li>
                <li><span class="mx-2">/</span></li>
                <li class="text-blue-600 font-semibold">Edit</li>
            </ol>
        </nav>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-lg rounded-lg p-6">
                <h3 class="text-lg font-semibold text-gray-700 mb-4">Formulir Edit Kunjungan Ibu Bersalin</h3>

                <form action="<?php echo e(route('kunjungan-ibu-bersalin.update', $kunjungan->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?> <!-- Method PUT untuk update data -->

                    <!-- Nama Ibu -->
                    <div class="mb-4">
                        <label for="nama_ibu" class="block text-sm font-medium text-gray-700">Nama Ibu</label>
                        <p class="mt-1 text-sm text-gray-800 bg-gray-100 p-2 rounded"><?php echo e($kunjungan->nama_ibu); ?></p>
                        <!-- Hidden input untuk anggota_keluarga_id -->
                        <input type="hidden" name="anggota_keluarga_id" value="<?php echo e($kunjungan->anggota_keluarga_id); ?>">
                        <!-- Hidden input untuk nama ibu -->
                        <input type="hidden" name="nama_ibu" value="<?php echo e($kunjungan->nama_ibu); ?>">
                    </div>

                    <!-- Umur Ibu -->
                    <div class="mb-4">
                        <label for="umur_ibu" class="block text-sm font-medium text-gray-700">Umur Ibu</label>
                        <input type="number" id="umur_ibu" name="umur_ibu" value="<?php echo e($kunjungan->umur_ibu); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-gray-100" readonly>
                    </div>

                    <!-- Tanggal Persalinan -->
                    <div class="mb-4">
                        <label for="tanggal_persalinan" class="block text-sm font-medium text-gray-700">Tanggal Persalinan</label>
                        <input type="date" id="tanggal_persalinan" name="tanggal_persalinan" value="<?php echo e($kunjungan->tanggal_persalinan); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Usia Kehamilan Saat Persalinan -->
                    <div class="mb-4">
                        <label for="usia_kehamilan_saat_persalinan" class="block text-sm font-medium text-gray-700">Usia Kehamilan Saat Persalinan (minggu)</label>
                        <input type="number" id="usia_kehamilan_saat_persalinan" name="usia_kehamilan_saat_persalinan" value="<?php echo e($kunjungan->usia_kehamilan_saat_persalinan); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" min="20" max="45" required>
                    </div>

                    <!-- Kelahiran Anak Ke -->
                    <div class="mb-4">
                        <label for="kelahiran_anak_ke" class="block text-sm font-medium text-gray-700">Kelahiran Anak Ke</label>
                        <input type="number" id="kelahiran_anak_ke" name="kelahiran_anak_ke" value="<?php echo e($kunjungan->kelahiran_anak_ke); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Pukul Persalinan -->
                    <div class="mb-4">
                        <label for="pukul_persalinan" class="block text-sm font-medium text-gray-700">Pukul Persalinan</label>
                        <input type="time" id="pukul_persalinan" name="pukul_persalinan" value="<?php echo e($kunjungan->pukul_persalinan); ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" required>
                    </div>

                    <!-- Penolong Persalinan -->
                    <div class="mb-4">
                        <label for="penolong_persalinan" class="block text-sm font-medium text-gray-700">Penolong Persalinan</label>
                        <select id="penolong_persalinan" name="penolong_persalinan" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" required>
                            <option value="Bidan" <?php echo e($kunjungan->penolong_persalinan == 'Bidan' ? 'selected' : ''); ?>>Bidan</option>
                            <option value="Dokter Umum" <?php echo e($kunjungan->penolong_persalinan == 'Dokter Umum' ? 'selected' : ''); ?>>Dokter Umum</option>
                            <option value="Dokter SpOG" <?php echo e($kunjungan->penolong_persalinan == 'Dokter SpOG' ? 'selected' : ''); ?>>Dokter SpOG</option>
                            <option value="Lainnya" <?php echo e($kunjungan->penolong_persalinan == 'Lainnya' ? 'selected' : ''); ?>>Lainnya</option>
                        </select>
                    </div>

                    <!-- Tempat Persalinan -->
                    <div class="mb-4">
                        <label for="tempat_persalinan" class="block text-sm font-medium text-gray-700">Tempat Persalinan</label>
                        <select id="tempat_persalinan" name="tempat_persalinan" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" required>
                            <option value="Posyandu Prima" <?php echo e($kunjungan->tempat_persalinan == 'Posyandu Prima' ? 'selected' : ''); ?>>Posyandu Prima</option>
                            <option value="Puskesmas" <?php echo e($kunjungan->tempat_persalinan == 'Puskesmas' ? 'selected' : ''); ?>>Puskesmas</option>
                            <option value="Rumah Sakit" <?php echo e($kunjungan->tempat_persalinan == 'Rumah Sakit' ? 'selected' : ''); ?>>Rumah Sakit</option>
                            <option value="Klinik" <?php echo e($kunjungan->tempat_persalinan == 'Klinik' ? 'selected' : ''); ?>>Klinik</option>
                            <option value="Bidan Praktik Mandiri" <?php echo e($kunjungan->tempat_persalinan == 'Bidan Praktik Mandiri' ? 'selected' : ''); ?>>Bidan Praktik Mandiri</option>
                            <option value="Lainnya" <?php echo e($kunjungan->tempat_persalinan == 'Lainnya' ? 'selected' : ''); ?>>Lainnya</option>
                        </select>
                    </div>

                    <!-- Keadaan Ibu -->
                    <div class="mb-4">
                        <label for="keadaan_ibu" class="block text-sm font-medium text-gray-700">Keadaan Ibu</label>
                        <select id="keadaan_ibu" name="keadaan_ibu" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm" required>
                            <option value="Sehat" <?php echo e($kunjungan->keadaan_ibu == 'Sehat' ? 'selected' : ''); ?>>Sehat</option>
                            <option value="Pendarahan" <?php echo e($kunjungan->keadaan_ibu == 'Pendarahan' ? 'selected' : ''); ?>>Pendarahan</option>
                            <option value="Demam" <?php echo e($kunjungan->keadaan_ibu == 'Demam' ? 'selected' : ''); ?>>Demam</option>
                            <option value="Kejang" <?php echo e($kunjungan->keadaan_ibu == 'Kejang' ? 'selected' : ''); ?>>Kejang</option>
                            <option value="Lokhia Berbau" <?php echo e($kunjungan->keadaan_ibu == 'Lokhia Berbau' ? 'selected' : ''); ?>>Lokhia Berbau</option>
                            <option value="Lainnya" <?php echo e($kunjungan->keadaan_ibu == 'Lainnya' ? 'selected' : ''); ?>>Lainnya</option>
                        </select>
                    </div>

                    <!-- Inisiasi Menyusu Dini (IMD) -->
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700">Inisiasi Menyusu Dini (IMD)</label>
                        <div class="mt-1">
                            <label class="inline-flex items-center">
                                <input type="radio" name="inisiasi_menyusu_dini" value="1" <?php echo e($kunjungan->inisiasi_menyusu_dini == 1 ? 'checked' : ''); ?> class="form-radio" required>
                                <span class="ml-2">Ya</span>
                            </label>
                            <label class="inline-flex items-center ml-4">
                                <input type="radio" name="inisiasi_menyusu_dini" value="0" <?php echo e($kunjungan->inisiasi_menyusu_dini == 0 ? 'checked' : ''); ?> class="form-radio" required>
                                <span class="ml-2">Tidak</span>
                            </label>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="flex justify-end items-center mt-6 space-x-2">
                        <button type="submit" class="bg-gray-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded shadow">
                            Simpan Perubahan
                        </button>
                        <a href="<?php echo e(route('keluarga')); ?>" class="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded shadow text-center">
                            Kembali
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/kunjungan-ibu-bersalin/edit.blade.php ENDPATH**/ ?>