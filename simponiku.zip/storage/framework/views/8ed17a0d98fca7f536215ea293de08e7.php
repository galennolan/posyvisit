<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Statistik Kategori Keluarga')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <!-- Filter Rekapitulasi -->
                    <div class="bg-white p-4 rounded-lg shadow mt-8">
                        <h2 class="font-bold text-2xl mb-4">Filter Rekapitulasi</h2>
                        <form method="GET" action="<?php echo e(route('statistik')); ?>" class="space-y-4">
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                            <!-- Pilihan Kecamatan -->
                            <div class="flex flex-col">
                                <label for="kecamatan" class="block text-sm font-medium text-gray-700">Kecamatan</label>
                                <select id="kecamatan" name="kecamatan" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                                    <?php if(Auth::user()->hasRole('PetugasKesehatan')): ?>
                                        <option value="<?php echo e(Auth::user()->kecamatan); ?>" <?php echo e(request('kecamatan') == Auth::user()->kecamatan ? 'selected' : ''); ?>>
                                            <?php echo e(Auth::user()->kecamatan); ?>

                                        </option>
                                    <?php else: ?>
                                        <option value="all" <?php echo e(request('kecamatan') == 'all' ? 'selected' : ''); ?>>Semua Kecamatan</option>
                                        <option value="Banjarsari" <?php echo e(request('kecamatan') == 'Banjarsari' ? 'selected' : ''); ?>>Banjarsari</option>
                                        <option value="Jebres" <?php echo e(request('kecamatan') == 'Jebres' ? 'selected' : ''); ?>>Jebres</option>
                                        <option value="Laweyan" <?php echo e(request('kecamatan') == 'Laweyan' ? 'selected' : ''); ?>>Laweyan</option>
                                        <option value="Pasar Kliwon" <?php echo e(request('kecamatan') == 'Pasar Kliwon' ? 'selected' : ''); ?>>Pasar Kliwon</option>
                                        <option value="Serengan" <?php echo e(request('kecamatan') == 'Serengan' ? 'selected' : ''); ?>>Serengan</option>
                                    <?php endif; ?>
                                </select>
                            </div>


                            <!-- Pilihan Kelurahan -->
                            <div class="flex flex-col">
                                <label for="kelurahan" class="block text-sm font-medium text-gray-700">Kelurahan</label>
                                <select id="kelurahan" name="kelurahan" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                                    <option value="all" <?php echo e(request('kelurahan') == 'all' ? 'selected' : ''); ?>>Semua Kelurahan</option>
                                </select>
                            </div>

                            <!-- Pilihan Posyandu -->
                            <div class="flex flex-col">
                                <label for="posyandu" class="block text-sm font-medium text-gray-700">Posyandu</label>
                                <select id="posyandu" name="posyandu" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                                    <?php if(Auth::user()->hasRole('KetuaPosyandu')): ?>
                                        <option value="<?php echo e(Auth::user()->nama_posyandu); ?>" <?php echo e(request('posyandu') == Auth::user()->nama_posyandu ? 'selected' : ''); ?>>
                                            <?php echo e(Auth::user()->nama_posyandu); ?>

                                        </option>
                                    <?php else: ?>
                                        <option value="all" <?php echo e(request('posyandu') == 'all' ? 'selected' : ''); ?>>Semua Posyandu</option>
                                        <?php $__currentLoopData = $posyandus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posyanduOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($posyanduOption); ?>" <?php echo e(request('posyandu') == $posyanduOption ? 'selected' : ''); ?>>
                                                <?php echo e($posyanduOption); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>

                        </div>

                        <!-- Tombol Filter -->
                        <div class="flex justify-end mt-4">
                            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                                Filter Data
                            </button>
                        </div>
                    </form>

                    </div>

                    <!-- Tampilkan Statistik -->
                    <?php if(isset($statistik)): ?>
                        <div class="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <!-- Rekapitulasi Keluarga -->
                            <div class="bg-green-100 p-6 rounded-lg shadow-lg text-center">
                            <h2 class="font-bold text-xl mb-2">
                                    <!-- Jika user adalah admin atau memilih kecamatan, tampilkan nama kecamatan -->
                                    <?php if(Auth::user()->hasRole('admin')): ?>
                                        <?php echo e(request('kecamatan') && request('kecamatan') != 'all' ? request('kecamatan') : 'Semua Kecamatan'); ?>

                                    <?php elseif(Auth::user()->hasRole('PetugasKesehatan')): ?>
                                        <!-- Jika user adalah PetugasKesehatan, tampilkan kecamatannya -->
                                        <?php echo e(Auth::user()->kecamatan); ?>

                                    <?php else: ?>
                                        <!-- Tampilkan kecamatan yang dipilih -->
                                        <?php echo e(request('kecamatan') && request('kecamatan') != 'all' ? request('kecamatan') : 'Semua Kecamatan'); ?>

                                    <?php endif; ?>
                                </h2>  
                            </div>
                            <div class="bg-teal-100 p-6 rounded-lg shadow-lg text-center">
                                <h2 class="font-bold text-xl mb-2"><?php echo e(request('kelurahan') && request('kelurahan') != 'all' ? request('kelurahan') : 'Semua Kelurahan'); ?></h2>
                               
                            </div>
                            <div class="bg-orange-100 p-6 rounded-lg shadow-lg text-center">
                                <h2 class="font-bold text-xl mb-2">  <!-- Jika user adalah KetuaPosyandu, tampilkan nama posyandu -->
                                    <?php if(Auth::user()->hasRole('KetuaPosyandu')): ?>
                                        <?php echo e(Auth::user()->nama_posyandu); ?>

                                    <?php else: ?>
                                        <!-- Tampilkan posyandu yang dipilih -->
                                        <?php echo e(request('posyandu') && request('posyandu') != 'all' ? request('posyandu') : 'Semua Posyandu'); ?>

                                    <?php endif; ?>
                                </h2>
                            </div>

                            <!-- Statistik Jumlah Keluarga dan Anggota Keluarga -->
                            <div class="bg-blue-100 p-6 rounded-lg shadow-lg text-center">
                                <h2 class="font-bold text-xl mb-2">Jumlah Keluarga</h2>
                                <p class="text-5xl font-bold"><?php echo e($statistik['jumlahKeluarga']); ?></p>
                            </div>
                            <div class="bg-purple-100 p-6 rounded-lg shadow-lg text-center">
                                <h2 class="font-bold text-xl mb-2">Jumlah Anggota Keluarga</h2>
                                <p class="text-5xl font-bold"><?php echo e($statistik['jumlahAnggotaKeluarga']); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery dan Script Dinamis untuk Kelurahan -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        const kelurahanOptions = {
            'Banjarsari': [
                'Banjarsari', 'Banyuanyar', 'Gilingan', 'Joglo', 'Kadipiro',
                'Keprabon', 'Kestalan', 'Ketelan', 'Manahan', 'Mangkubumen',
                'Nusukan', 'Punggawan', 'Setabelan', 'Sumber Timuran'
            ],
            'Jebres': [
                'Gandekan', 'Jagalan', 'Jebres', 'Kepatihan Kulon', 'Kepatihan Wetan',
                'Mojosongo', 'Pucang Sawit', 'Purwodiningratan', 'Sewu',
                'Sudiroprajan', 'Tegalharjo'
            ],
            'Laweyan': [
                'Bumi', 'Jajar', 'Karangasem', 'Kerten', 'Laweyan', 'Pajang',
                'Panularan', 'Penumping', 'Purwosari', 'Sondakan', 'Sriwedari'
            ],
            'Pasar Kliwon': [
                'Baluwarti', 'Gajahan', 'Joyosuran', 'Kampung Baru', 'Kauman',
                'Kedung Lumbu', 'Mojo', 'Pasar Kliwon', 'Sangkrah', 'Semanggi'
            ],
            'Serengan': [
                'Danukusuman', 'Jayengan', 'Joyotakan', 'Kemlayan', 'Kratonan',
                'Serengan', 'Tipes'
            ]
        };

        $(document).ready(function() {
            $('#kecamatan').on('change', function() {
                var kecamatan = $(this).val();
                var kelurahanDropdown = $('#kelurahan');
                kelurahanDropdown.empty().append('<option value="all">Semua Kelurahan</option>');
                
                if (kecamatan && kelurahanOptions[kecamatan]) {
                    kelurahanOptions[kecamatan].forEach(function(kelurahan) {
                        kelurahanDropdown.append('<option value="' + kelurahan + '">' + kelurahan + '</option>');
                    });
                }
            });

            // Menginisialisasi kelurahan jika kecamatan sudah dipilih sebelumnya
            var selectedKecamatan = $('#kecamatan').val();
            if (selectedKecamatan && kelurahanOptions[selectedKecamatan]) {
                var kelurahanDropdown = $('#kelurahan');
                kelurahanDropdown.empty().append('<option value="all">Semua Kelurahan</option>');

                kelurahanOptions[selectedKecamatan].forEach(function(kelurahan) {
                    var isSelected = '<?php echo e(request('kelurahan')); ?>' === kelurahan ? 'selected' : '';
                    kelurahanDropdown.append('<option value="' + kelurahan + '" ' + isSelected + '>' + kelurahan + '</option>');
                });
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/statistik.blade.php ENDPATH**/ ?>