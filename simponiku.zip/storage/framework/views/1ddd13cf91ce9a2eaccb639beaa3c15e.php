<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Daftar Kader Posyandu')); ?>

        </h2>
        <nav class="breadcrumb">
            <ol class="list-reset flex text-sm">
                <li><a href="/dashboard" class="text-blue-600 hover:text-blue-800">Home </a></li>
                <li><span class="mx-2">/ </span></li>
                <li class="text-blue-600 font-semibold"> Daftar Kader Posyandu</li>
            </ol>
        </nav>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php if(session('success')): ?>
                        <div class="bg-green-500 text-white p-4 mb-4 rounded-lg">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <!-- Dropdown untuk memilih kecamatan -->
                    <div class="mb-4 flex justify-between items-center">
                    <?php if(!Auth::user()->hasRole('PetugasKesehatan')): ?>
                        <form action="<?php echo e(route('admin.users.filter')); ?>" method="POST">
                        <?php echo csrf_field(); ?> <!-- Include CSRF token -->
                            <label for="kecamatan" class="mr-2">Pilih Kecamatan:</label>
                            <select name="kecamatan" id="kecamatan" class="border rounded p-2 w-40">
                                <option value="">--- Pilih Kec ---</option>
                                <!-- Tambahkan opsi kecamatan sesuai dengan yang ada di database -->
                                <option value="Pasar Kliwon" <?php echo e((isset($kecamatan) && $kecamatan == 'Pasar Kliwon') ? 'selected' : ''); ?>>Pasar Kliwon</option>
                                <option value="Banjarsari" <?php echo e((isset($kecamatan) && $kecamatan == 'Banjarsari') ? 'selected' : ''); ?>>Banjarsari</option>
                                <option value="Laweyan" <?php echo e((isset($kecamatan) && $kecamatan == 'Laweyan') ? 'selected' : ''); ?>>Laweyan</option>
                                <option value="Serengan" <?php echo e((isset($kecamatan) && $kecamatan == 'Serengan') ? 'selected' : ''); ?>>Serengan</option>
                               
                                <option value="Jebres" <?php echo e((isset($kecamatan) && $kecamatan == 'Jebres') ? 'selected' : ''); ?>>Jebres</option>
                            </select>
                            <button type="submit" class="bg-blue-500 text-white rounded p-2 ml-2">Tampilkan</button>
                        </form>
                        <?php endif; ?>
                        <!-- Bagian kanan: Tombol Tambah User -->
                        <a href="<?php echo e(route('admin.users.create')); ?>" class="bg-green-500 text-white rounded p-2 hover:bg-green-700">
                            Tambah User
                        </a>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="min-w-full table-auto divide-y divide-gray-200 dark:divide-gray-700">
                            <thead>
                                <tr>
                                    <th class="px-6 py-3 bg-gray-50 dark:bg-gray-900 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Nama
                                    </th>
                                    <th class="px-6 py-3 bg-gray-50 dark:bg-gray-900 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Email
                                    </th>
                                    <th class="px-6 py-3 bg-gray-50 dark:bg-gray-900 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Asal
                                    </th>
                                    <th class="px-6 py-3 bg-gray-50 dark:bg-gray-900 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Kelurahan
                                    </th>
                                    <th class="px-6 py-3 bg-gray-50 dark:bg-gray-900 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Nama Posyandu
                                    </th>
                                    <th class="px-6 py-3 bg-gray-50 dark:bg-gray-900 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                                        Aksi
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                // Tetapkan warna latar belakang berdasarkan kecamatan
                                $bgColor = match($user->kecamatan) {
                                    'Banjarsari' => 'bg-green-100 dark:bg-green-800', // Hijau
                                    'Jebres' => 'bg-yellow-100 dark:bg-yellow-800', // Kuning
                                    'Laweyan' => 'bg-purple-100 dark:bg-purple-800', // Ungu
                                    'Pasar Kliwon' => 'bg-cyan-100 dark:bg-cyan-800', // Biru
                                    'Serengan' => 'bg-red-100 dark:bg-red-800', // Merah
                                    default => 'bg-gray-100 dark:bg-gray-700', // Default jika tidak ada yang cocok
                                };
                            ?>

                            <tr class="<?php echo e($bgColor); ?>">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900 dark:text-gray-300"><?php echo e($user->name); ?></div>
                                    <div class="text-xs text-gray-600 dark:text-gray-400">
                                        <?php echo e($user->roles->pluck('name')->join(', ')); ?>

                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900 dark:text-gray-300"><?php echo e($user->email); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900 dark:text-gray-300">Kec.<?php echo e($user->kecamatan); ?></div>
                                    <div class="text-xs text-gray-600 dark:text-gray-400">
                                        Kel. <?php echo e($user->kelurahan); ?>

                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900 dark:text-gray-300"><?php echo e($user->kelurahan); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900 dark:text-gray-300"><?php echo e($user->nama_posyandu); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="text-indigo-600 dark:text-indigo-400 hover:text-indigo-900">Edit</a>
                                    <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 dark:text-red-400 hover:text-red-900 ml-4" onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div> <!-- End of overflow-x-auto -->
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/admin/users/index.blade.php ENDPATH**/ ?>