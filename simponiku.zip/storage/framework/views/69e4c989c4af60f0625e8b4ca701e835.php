<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Formulir Pendaftaran Pengguna')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                <div class="max-w-xl">
                    <?php if($errors->any()): ?>
                        <div class="bg-red-500 text-white p-4 mb-4 rounded-lg">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <!-- Input Nama -->
                        <div class="mb-6">
                            <label for="name" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Nama</label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring focus:ring-blue-500" required>
                        </div>

                        <!-- Pilih Role -->
                        <div class="mb-6">
                            <label for="role" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Pilih Role</label>
                            <select name="role" id="role" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring focus:ring-blue-500" required>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->name); ?>"><?php echo e(ucfirst($role->name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Input Kecamatan -->
                        <div class="mb-6">
                            <label for="kecamatan" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Kecamatan</label>
                            <select name="kecamatan" id="kecamatan" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring focus:ring-blue-500" required>
                            <?php $__currentLoopData = $kecamatanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kecamatan); ?>"><?php echo e($kecamatan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Input Kelurahan -->
                        <div class="mb-6">
                            <label for="kelurahan" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Kelurahan</label>
                            <select name="kelurahan" id="kelurahan" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring focus:ring-blue-500" required>
                                <option value="">Pilih Kelurahan</option>
                            </select>
                        </div>

                        <!-- Input Nama Posyandu -->
                        <div class="mb-6">
                            <label for="nama_posyandu" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Nama Posyandu</label>
                            <input type="text" name="nama_posyandu" id="nama_posyandu" value="<?php echo e(old('nama_posyandu')); ?>" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring focus:ring-blue-500" required>
                        </div>

                        <!-- Input Email -->
                        <div class="mb-6">
                            <label for="email" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Email</label>
                            <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring focus:ring-blue-500" required>
                        </div>

                        <!-- Input Password -->
                        <div class="mb-6">
                            <label for="password" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Password</label>
                            <input type="password" name="password" id="password" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring focus:ring-blue-500" required>
                        </div>

                        <!-- Konfirmasi Password -->
                        <div class="mb-6">
                            <label for="password_confirmation" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Konfirmasi Password</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="border border-gray-300 rounded-lg p-3 w-full focus:outline-none focus:ring focus:ring-blue-500" required>
                        </div>

                        <!-- Submit Button -->
                        <div>
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="bg-red-500 text-white px-4 py-2 rounded-lg mr-2 hover:bg-gray-600">Batal</a>
                            <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition duration-200">Buat User</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const kelurahanOptions = {
            'Banjarsari': [
                'Banjarsari',
                'Banyuanyar',
                'Gilingan',
                'Joglo',
                'Kadipiro',
                'Keprabon',
                'Kestalan',
                'Ketelan',
                'Manahan',
                'Mangkubumen',
                'Nusukan',
                'Punggawan',
                'Setabelan',
                'Sumber Timuran'
            ],
            'Jebres': [
                'Gandekan',
                'Jagalan',
                'Jebres',
                'Kepatihan Kulon',
                'Kepatihan Wetan',
                'Mojosongo',
                'Pucang Sawit',
                'Purwodiningratan',
                'Sewu',
                'Sudiroprajan',
                'Tegalharjo'
            ],
            'Laweyan': [
                'Bumi',
                'Jajar',
                'Karangasem',
                'Kerten',
                'Laweyan',
                'Pajang',
                'Panularan',
                'Penumping',
                'Purwosari',
                'Sondakan',
                'Sriwedari'
            ],
            'Pasar Kliwon': [
                'Baluwarti',
                'Gajahan',
                'Joyosuran',
                'Kampung Baru',
                'Kauman',
                'Kedung Lumbu',
                'Mojo',
                'Pasar Kliwon',
                'Sangkrah',
                'Semanggi'
            ],
            'Serengan': [
                'Danukusuman',
                'Jayengan',
                'Joyotakan',
                'Kemlayan',
                'Kratonan',
                'Serengan',
                'Tipes'
            ]
        };

        const kelurahanSelect = document.getElementById('kelurahan');
        const kecamatanSelect = document.getElementById('kecamatan');

        // Fungsi untuk update kelurahan
        function updateKelurahan(kecamatan) {
            kelurahanSelect.innerHTML = '<option value="">Pilih Kelurahan</option>';
            if (kelurahanOptions[kecamatan]) {
                kelurahanOptions[kecamatan].forEach(function(kelurahan) {
                    const option = document.createElement('option');
                    option.value = kelurahan;
                    option.textContent = kelurahan;
                    kelurahanSelect.appendChild(option);
                });
            }
        }

        // Event listener saat kecamatan diubah
        kecamatanSelect.addEventListener('change', function() {
            updateKelurahan(this.value);
        });

        // Update kelurahan saat halaman dimuat, jika kecamatan user sudah dipilih
        document.addEventListener('DOMContentLoaded', function() {
            const selectedKecamatan = kecamatanSelect.value;
            if (selectedKecamatan) {
                updateKelurahan(selectedKecamatan);
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/admin/users/create.blade.php ENDPATH**/ ?>