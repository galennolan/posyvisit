<div class="text-left text-sm md:text-base">    
    <p><strong>Tanggal Pengumpulan Data:</strong> <?php echo e(\Carbon\Carbon::parse($keluarga->tanggal_pengumpulan_data)->format('d/m/Y')); ?></p>
    <p><strong>Alamat:</strong> <?php echo e($keluarga->alamat); ?></p>
    <p><strong>No Handphone:</strong> <?php echo e($keluarga->no_handphone); ?></p>
    <p><strong>Puskesmas:</strong> <?php echo e($keluarga->puskesmas); ?></p>
    <p><strong>Kecamatan:</strong> <?php echo e($keluarga->kecamatan); ?></p>
    <p><strong>Kelurahan:</strong> <?php echo e($keluarga->kelurahan); ?></p>
    <p><strong>Pustu/Posyandu Prima:</strong> <?php echo e($keluarga->pustu); ?></p>
    <p><strong>JKN:</strong> <?php echo e($keluarga->jkn); ?></p>
    <p><strong>Sarana Air Bersih:</strong> <?php echo e($keluarga->sarana_air_bersih); ?></p>
    <p><strong>Jenis Sumber Air:</strong> <?php echo e($keluarga->jenis_sumber_air ?? 'Tidak Tersedia'); ?></p>
    <p><strong>Jamban Keluarga:</strong> <?php echo e($keluarga->jamban_keluarga); ?></p>
    <p><strong>Jenis Jamban:</strong> <?php echo e($keluarga->jenis_jamban ?? 'Tidak Tersedia'); ?></p>
    <p><strong>Ventilasi:</strong> <?php echo e($keluarga->ventilasi); ?></p>
    <p><strong>Gangguan Jiwa:</strong> <?php echo e($keluarga->gangguan_jiwa); ?></p>
    <p><strong>Terdiagnosis Penyakit (TBC, Hipertensi, Diabetes Melitus):</strong> <?php echo e($keluarga->terdiagnosis_penyakit); ?></p>


    <h3 class="text-lg font-semibold mt-4">Anggota Keluarga</h3>
    <ul class="list-disc pl-5 text-xs"> <!-- Perkecil ukuran font dengan text-sm -->
        <?php $__currentLoopData = $keluarga->anggotaKeluarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="mb-2">
                <span><strong>Nama:</strong> <?php echo e($anggota->nama_lengkap); ?>, </span>
                <span><strong>NIK:</strong> <?php echo e($anggota->nik); ?>, </span>
                <span><strong>Tanggal Lahir:</strong> <?php echo e(\Carbon\Carbon::parse($anggota->tanggal_lahir)->format('d/m/Y')); ?>, </span>
                <span><strong>Jenis Kelamin:</strong> <?php echo e($anggota->jenis_kelamin); ?>, </span>
                <span><strong>Hubungan KK:</strong> 
                    <?php switch($anggota->hubungan_kk):
                        case (1): ?>
                            Kepala Keluarga
                            <?php break; ?>
                        <?php case (2): ?>
                            Suami
                            <?php break; ?>
                        <?php case (3): ?>
                            Istri
                            <?php break; ?>
                        <?php case (4): ?>
                            Anak
                            <?php break; ?>
                        <?php case (5): ?>
                            Menantu
                            <?php break; ?>
                        <?php case (6): ?>
                            Cucu
                            <?php break; ?>
                        <?php case (7): ?>
                            Orang Tua
                            <?php break; ?>
                        <?php case (8): ?>
                            Mertua
                            <?php break; ?>
                        <?php case (9): ?>
                            Anggota Lain
                            <?php break; ?>
                    <?php endswitch; ?>
                    , 
                </span>
                <span><strong>Status Perkawinan:</strong> 
                    <?php switch($anggota->status_perkawinan):
                        case (1): ?>
                            Belum Menikah
                            <?php break; ?>
                        <?php case (2): ?>
                            Menikah
                            <?php break; ?>
                        <?php case (3): ?>
                            Cerai Hidup
                            <?php break; ?>
                        <?php case (4): ?>
                            Cerai Mati
                            <?php break; ?>
                    <?php endswitch; ?>
                    , 
                </span>
                <span><strong>Pendidikan Terakhir:</strong> 
                    <?php switch($anggota->pendidikan_terakhir):
                        case (1): ?>
                            Tidak Sekolah
                            <?php break; ?>
                        <?php case (2): ?>
                            SD
                            <?php break; ?>
                        <?php case (3): ?>
                            SMP
                            <?php break; ?>
                        <?php case (4): ?>
                            SMA
                            <?php break; ?>
                        <?php case (5): ?>
                            Diploma
                            <?php break; ?>
                        <?php case (6): ?>
                            Sarjana
                            <?php break; ?>
                    <?php endswitch; ?>
                    , 
                </span>
                <span><strong>Pekerjaan:</strong> 
                    <?php switch($anggota->pekerjaan):
                        case (1): ?>
                            Tidak Bekerja
                            <?php break; ?>
                        <?php case (2): ?>
                            Petani
                            <?php break; ?>
                        <?php case (3): ?>
                            PNS
                            <?php break; ?>
                        <?php case (4): ?>
                            Buruh
                            <?php break; ?>
                        <?php case (5): ?>
                            Wiraswasta
                            <?php break; ?>
                        <?php case (6): ?>
                            Pelajar
                            <?php break; ?>
                        <?php case (7): ?>
                            Lainnya
                            <?php break; ?>
                    <?php endswitch; ?>
                    , 
                </span>
                <span><strong>Kelompok Sasaran:</strong> <?php echo e($anggota->kelompok_sasaran); ?></span>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/keluarga/detail.blade.php ENDPATH**/ ?>