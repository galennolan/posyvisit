<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
    <circle cx="32" cy="32" r="30" stroke="#3b82f6" stroke-width="4" fill="none"/>
    <rect x="28" y="16" width="8" height="32" fill="#3b82f6"/>
    <rect x="16" y="28" width="32" height="8" fill="#3b82f6"/>
</svg><?php /**PATH C:\laragon\www\posyvisit\resources\views/components/application-logo.blade.php ENDPATH**/ ?>