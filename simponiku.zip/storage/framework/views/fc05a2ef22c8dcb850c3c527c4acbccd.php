<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Data Kunjungan Usia Sekolah dan Remaja')); ?>

        </h2>
        <nav class="breadcrumb">
            <ol class="list-reset flex text-sm">
                <li><a href="/dashboard" class="text-blue-600 hover:text-blue-800">Home</a></li>
                <li><span class="mx-2">/</span></li>
                <li class="text-blue-600 font-semibold"><a href="<?php echo e(route('kunjungan-rumah-usia-remaja.index')); ?>" class="text-blue-600 hover:text-blue-800">Kunjungan Usia Sekolah dan Remaja</a></li>
            </ol>
        </nav>kunjungan-rumah-usia-remaja
     <?php $__env->endSlot(); ?>

    <div class="py-12" x-data="modalHandler()">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-lg rounded-lg p-6">
                <h3 class="text-lg font-semibold text-gray-700 mb-4">Daftar Kunjungan</h3>
                
                <!-- Form Pencarian -->
                <form method="GET" action="<?php echo e(route('kunjungan-rumah-usia-remaja.index')); ?>" class="mb-4">
                    <div class="flex">
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="border border-gray-300 rounded-md py-2 px-4" placeholder="Cari Nama Anak...">
                        <button type="submit" class="ml-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded">Cari</button>
                    </div>
                </form>
                
                <div class="table-responsive">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-500">No</th>
                                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-500">Nama Anak</th>
                                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-500">Umur</th>
                                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-500">Tanggal Kunjungan</th>
                                <th class="px-4 py-2 text-left text-sm font-semibold text-gray-500">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__empty_1 = true; $__currentLoopData = $kunjungan_remaja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kunjungan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50 transition duration-200">
                                    <td class="px-4 py-2 text-sm text-gray-500"><?php echo e($kunjungan_remaja->firstItem() + $index); ?></td>
                                    <td class="px-4 py-2 text-sm text-gray-700"><?php if($kunjungan->anggotaKeluarga): ?>
                                        <?php echo e($kunjungan->anggotaKeluarga->nama_lengkap); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?></td>
                                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e($kunjungan->umur_anak); ?> tahun</td>
                                    <td class="px-4 py-2 text-sm text-gray-700"><?php echo e(\Carbon\Carbon::parse($kunjungan->tanggal_kunjungan)->format('d/m/Y')); ?></td>
                                    <td class="px-4 py-2 flex space-x-2">
                                        <!-- Tombol Lihat -->
                                        <button class="text-blue-500 hover:text-blue-700" @click="openModal(<?php echo e($kunjungan->id); ?>)">
                                            Lihat
                                        </button>
                                        <a href="<?php echo e(route('kunjungan-rumah-usia-remaja.edit', $kunjungan->id)); ?>" class="text-yellow-500 hover:text-yellow-700">Edit</a>
                                        <form action="<?php echo e(route('kunjungan-rumah-usia-remaja.destroy', $kunjungan->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-500 hover:text-red-700">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4 text-gray-500">Tidak ada data yang ditemukan</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Link Pagination -->
                    <div class="mt-4">
                        <?php echo e($kunjungan_remaja->appends(request()->input())->links()); ?>

                    </div>

                    <!-- Modal -->
                    <div 
                        x-show="isOpen" 
                        class="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-75 z-50" 
                        style="display: none;" 
                        @keydown.window.escape="closeModal()"
                    >
                        <div class="bg-white p-6 rounded-lg shadow-lg max-w-lg w-full relative">
                            <!-- Tombol Tutup Modal di Sudut Kanan Atas -->
                            <button 
                                class="absolute top-3 right-3 text-gray-500 hover:text-gray-700" 
                                @click="closeModal()"
                                aria-label="Close"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>

                            <!-- Konten Modal -->
                            <h3 class="text-lg font-semibold text-gray-700 mb-4">Detail Kunjungan Usia Sekolah dan Remaja</h3>
                            <div x-html="modalContent"></div>
                        </div>
                    </div>

                    <script>
                        function modalHandler() {
                            return {
                                isOpen: false,
                                modalContent: '',
                                openModal(id) {
                                    this.isOpen = true;
                                    // Menggunakan AJAX untuk mendapatkan data detail kunjungan
                                    fetch(`/kunjungan-rumah-usia-remaja/${id}`)
                                        .then(response => response.text())
                                        .then(html => {
                                            this.modalContent = html; // Menampilkan konten di dalam modal
                                        });
                                },
                                closeModal() {
                                    this.isOpen = false;
                                    this.modalContent = ''; // Kosongkan konten modal saat ditutup
                                }
                            };
                        }
                    </script>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/kunjungan-rumah-usia-remaja/index.blade.php ENDPATH**/ ?>