<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard Posyandu')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100 space-y-4">
                    <!-- Informasi Posyandu atau Kecamatan -->
                    <?php if(Auth::user()->hasRole('Kader')): ?>
                        <div class="bg-yellow-100 p-4 rounded-lg shadow">
                            <h2 class="font-bold">Posyandu: <?php echo e(Auth::user()->nama_posyandu); ?></h2>
                        </div>
                    <?php endif; ?>

                    <?php if(Auth::user()->hasRole('PetugasKesehatan')): ?>
                        <div class="bg-yellow-100 p-4 rounded-lg shadow">
                            <h2 class="font-bold">Kecamatan: <?php echo e(Auth::user()->kecamatan); ?></h2>
                        </div>
                    <?php endif; ?>

                    <!-- Statistik Utama: Baris Pertama -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <!-- Jumlah Keluarga -->
                        <div class="bg-green-100 p-6 rounded-lg shadow-lg text-center">
                            <h2 class="font-bold text-3xl">Jumlah Keluarga</h2>
                            <p class="text-6xl font-bold"><?php echo e($jumlahKeluarga); ?></p>
                            <p class="text-lg"><?php echo e(number_format($persentaseKeluarga)); ?>% dari total</p>
                        </div>

                        <!-- Jumlah Anggota Keluarga -->
                        <div class="bg-blue-100 p-6 rounded-lg shadow-lg text-center">
                            <h2 class="font-bold text-3xl">Jumlah Anggota Keluarga</h2>
                            <p class="text-6xl font-bold"><?php echo e($jumlahAnggotaKeluarga); ?></p>
                            <p class="text-lg"><?php echo e(number_format($persentaseAnggotaKeluarga)); ?>% dari total</p>
                        </div>
                    </div>
                    <!-- Semua Kategori dalam Satu Card -->
                    <div class="bg-orange-100 p-4 rounded-lg shadow text-center">
                        <h2 class="font-bold text-xl mb-2">Statistik Kategori Keluarga</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 mt-2">
                            <!-- Ibu Bersalin & Nifas -->
                            <div class="text-sm">
                                <h3 class="font-semibold bg-yellow-300 text-black py-1 px-2 rounded-md inline-block">Ibu Bersalin & Nifas</h3>
                                <p class="text-2xl font-bold"><?php echo e($jumlahIbuBersalinNifas); ?></p>
                                <p class="text-base"><?php echo e(number_format($persentaseIbuBersalinNifas)); ?>% dari total</p>
                            </div>
                            
                            <!-- Bayi - Balita (0-6 tahun) -->
                            <div class="text-sm">
                                <h3 class="font-semibold bg-yellow-300 text-black py-1 px-2 rounded-md inline-block">Bayi - Balita (0-6 tahun)</h3>
                                <p class="text-2xl font-bold"><?php echo e($jumlahBayiBalita); ?></p>
                                <p class="text-base"><?php echo e(number_format($persentaseBayiBalita)); ?>% dari total</p>
                            </div>
                            
                            <!-- Bayi Apras (≥6 - 71 bulan) -->
                            <div class="text-sm">
                                <h3 class="font-semibold bg-yellow-300 text-black py-1 px-2 rounded-md inline-block">Bayi Apras (≥6 - 71 bulan)</h3>
                                <p class="text-2xl font-bold"><?php echo e($jumlahBayiApras); ?></p>
                                <p class="text-base"><?php echo e(number_format($persentaseBayiApras)); ?>% dari total</p>
                            </div>
                            
                            <!-- Usia Sekolah & Remaja (≥6 - <18 tahun) -->
                            <div class="text-sm">
                                <h3 class="font-semibold bg-yellow-300 text-black py-1 px-2 rounded-md inline-block">Usia Sekolah & Remaja</h3>
                                <p class="text-2xl font-bold"><?php echo e($jumlahUsiaSekolahRemaja); ?></p>
                                <p class="text-base"><?php echo e(number_format($persentaseUsiaSekolahRemaja)); ?>% dari total</p>
                            </div>
                            
                            <!-- Usia Dewasa (≥18-59 tahun) -->
                            <div class="text-sm">
                                <h3 class="font-semibold bg-yellow-300 text-black py-1 px-2 rounded-md inline-block">Usia Dewasa (≥18-59 tahun)</h3>
                                <p class="text-2xl font-bold"><?php echo e($jumlahUsiaDewasa); ?></p>
                                <p class="text-base"><?php echo e(number_format($persentaseUsiaDewasa)); ?>% dari total</p>
                            </div>
                            
                            <!-- Lansia (≥60 tahun) -->
                            <div class="text-sm">
                                 <h3 class="font-semibold bg-yellow-300 text-black py-1 px-2 rounded-md inline-block">Lansia (≥60 tahun)</h3>
                                <p class="text-2xl font-bold"><?php echo e($jumlahLansia); ?></p>
                                <p class="text-base"><?php echo e(number_format($persentaseLansia)); ?>% dari total</p>
                            </div>

                            <!-- Ibu Hamil -->
                            <div class="text-sm">
                                 <h3 class="font-semibold bg-yellow-300 text-black py-1 px-2 rounded-md inline-block">Ibu Hamil</h3>
                                <p class="text-2xl font-bold"><?php echo e($jumlahIbuHamil); ?></p>
                                <p class="text-base"><?php echo e(number_format($persentaseIbuHamil)); ?>% dari total</p>
                            </div>
                        </div>
                    </div>

                   
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/dashboard.blade.php ENDPATH**/ ?>