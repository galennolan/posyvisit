<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('FORM CHEKLIST KUNJUNGAN RUMAH')); ?>

        </h2>
        <nav class="breadcrumb">
            <ol class="list-reset flex text-sm">
                <li><a href="/dashboard" class="text-blue-600 hover:text-blue-800">Home </a></li>
                <li><span class="mx-2">/ </span></li>
                <li class="text-blue-600 font-semibold"> <a href="/keluarga/" class="text-blue-600 hover:text-blue-800">Kunjungan Rumah</a></li>
            </ol>
        </nav>
     <?php $__env->endSlot(); ?>

    <div class="py-12 px-6 sm:px-8 lg:px-10">
        <!-- Main Form Card -->
        <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 sm:p-8 space-y-6">
            <div class="bg-gradient-to-r from-blue-500 to-indigo-600 p-6 rounded-lg shadow-lg">
                <h3 class="text-2xl font-bold text-white tracking-wide uppercase">
                    Form Checklist Kunjungan Rumah
                </h3>
            </div>

            <form action="<?php echo e(route('keluarga.update', $keluarga->id)); ?>" method="POST" class="p-6 space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Tanggal Pengumpulan Data -->
                    <div class="col-span-1">
                        <label for="tanggal_pengumpulan_data" class="block text-sm font-medium text-gray-700">Tanggal Pengumpulan Data</label>
                        <input type="date" id="tanggal_pengumpulan_data" name="tanggal_pengumpulan_data" value="<?php echo e($keluarga->tanggal_pengumpulan_data); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['tanggal_pengumpulan_data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['tanggal_pengumpulan_data'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Alamat -->
                    <div class="col-span-1">
                        <label for="alamat" class="block text-sm font-medium text-gray-700">Alamat</label>
                        <input type="text" id="alamat" name="alamat" value="<?php echo e($keluarga->alamat); ?>" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 dark:text-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- No Handphone -->
                    <div class="col-span-1">
                        <label for="no_handphone" class="block text-sm font-medium text-gray-700">No Handphone KK / salah satu anggota keluarga</label>
                        <input type="text" id="no_handphone" name="no_handphone" value="<?php echo e($keluarga->no_handphone); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['no_handphone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['no_handphone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Kabupaten / Kota -->
                    <div class="col-span-1">
                        <label for="kabupaten" class="block text-sm font-medium text-gray-700">Kabupaten / Kota</label>
                        <input type="text" id="kabupaten" name="kabupaten" value="Solo" readonly class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500">
                    </div>

                    <!-- Kecamatan -->
                    <div class="col-span-1">
                        <label for="kecamatan" class="block text-sm font-medium text-gray-700">Kecamatan</label>
                        <select id="kecamatan" name="kecamatan" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500">
                            <option value="Banjarsari" <?php echo e($keluarga->kecamatan === 'Banjarsari' ? 'selected' : ''); ?>>Banjarsari</option>
                            <option value="Jebres" <?php echo e($keluarga->kecamatan === 'Jebres' ? 'selected' : ''); ?>>Jebres</option>
                            <option value="Laweyan" <?php echo e($keluarga->kecamatan === 'Laweyan' ? 'selected' : ''); ?>>Laweyan</option>
                            <option value="Pasar Kliwon" <?php echo e($keluarga->kecamatan === 'Pasar Kliwon' ? 'selected' : ''); ?>>Pasar Kliwon</option>
                            <option value="Serengan" <?php echo e($keluarga->kecamatan === 'Serengan' ? 'selected' : ''); ?>>Serengan</option>
                        </select>
                    </div>

                    <!-- Kelurahan Dropdown -->
                    <div class="col-span-1">
                        <label for="kelurahan" class="block text-sm font-medium text-gray-700">Kelurahan</label>
                        <select id="kelurahan" name="kelurahan" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Kelurahan</option>
                        </select>
                        <?php $__errorArgs = ['kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <!-- Puskesmas -->
                    <div class="col-span-1">
                        <label for="puskesmas" class="block text-sm font-medium text-gray-700">Puskesmas</label>
                        <input type="text" id="puskesmas" name="puskesmas" value="<?php echo e($keluarga->puskesmas); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['puskesmas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['puskesmas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Pustu / Posyandu Prima -->
                    <div class="col-span-1">
                        <label for="pustu" class="block text-sm font-medium text-gray-700">Pustu/Posyandu Prima</label>
                        <input type="text" id="pustu" name="pustu" value="<?php echo e($keluarga->pustu); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['pustu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['pustu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Provinsi -->
                    <div class="col-span-1">
                        <label for="provinsi" class="block text-sm font-medium text-gray-700">Provinsi</label>
                        <input type="text" id="provinsi" name="provinsi" value="<?php echo e($keluarga->provinsi); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Provinsi -->
                    <div class="col-span-1">
                        <label for="provinsi" class="block text-sm font-medium text-gray-700">Provinsi</label>
                        <input type="text" id="provinsi" name="provinsi" value="<?php echo e(old('provinsi', $keluarga->provinsi)); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- JKN -->
                    <div class="col-span-1">
                        <label for="jkn" class="block text-sm font-medium text-gray-700">Jaminan Kesehatan Nasional (JKN)</label>
                        <select id="jkn" name="jkn" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['jkn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Status</option>
                            <option value="Ya" <?php echo e(old('jkn', $keluarga->jkn) == 'Ya' ? 'selected' : ''); ?>>Ya</option>
                            <option value="Tidak" <?php echo e(old('jkn', $keluarga->jkn) == 'Tidak' ? 'selected' : ''); ?>>Tidak</option>
                        </select>
                        <?php $__errorArgs = ['jkn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Sarana Air Bersih -->
                    <div class="col-span-1">
                        <label for="sarana_air_bersih" class="block text-sm font-medium text-gray-700">Sarana Air Bersih</label>
                        <select id="sarana_air_bersih" name="sarana_air_bersih" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['sarana_air_bersih'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Status</option>
                            <option value="Ya" <?php echo e(old('sarana_air_bersih', $keluarga->sarana_air_bersih) == 'Ya' ? 'selected' : ''); ?>>Ya</option>
                            <option value="Tidak" <?php echo e(old('sarana_air_bersih', $keluarga->sarana_air_bersih) == 'Tidak' ? 'selected' : ''); ?>>Tidak</option>
                        </select>
                        <?php $__errorArgs = ['sarana_air_bersih'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Jenis Sumber Air -->
                    <div class="col-span-1">
                        <label for="jenis_sumber_air" class="block text-sm font-medium text-gray-700">Jenis Sumber Air</label>
                        <select id="jenis_sumber_air" name="jenis_sumber_air" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['jenis_sumber_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Jenis</option>
                            <option value="Terlindung" <?php echo e(old('jenis_sumber_air', $keluarga->jenis_sumber_air) == 'Terlindung' ? 'selected' : ''); ?>>Terlindung</option>
                            <option value="Tidak_Terlindung" <?php echo e(old('jenis_sumber_air', $keluarga->jenis_sumber_air) == 'Tidak_Terlindung' ? 'selected' : ''); ?>>Tidak Terlindung</option>
                        </select>
                        <?php $__errorArgs = ['jenis_sumber_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Jamban Keluarga -->
                    <div class="col-span-1">
                        <label for="jamban_keluarga" class="block text-sm font-medium text-gray-700">Apakah tersedia jamban keluarga?</label>
                        <select id="jamban_keluarga" name="jamban_keluarga" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['jamban_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Status</option>
                            <option value="Ya" <?php echo e(old('jamban_keluarga', $keluarga->jamban_keluarga) == 'Ya' ? 'selected' : ''); ?>>Ya</option>
                            <option value="Tidak" <?php echo e(old('jamban_keluarga', $keluarga->jamban_keluarga) == 'Tidak' ? 'selected' : ''); ?>>Tidak</option>
                        </select>
                        <?php $__errorArgs = ['jamban_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Jenis Jamban -->
                    <div class="col-span-1">
                        <label for="jenis_jamban" class="block text-sm font-medium text-gray-700">Apakah jenis jambannya saniter?</label>
                        <select id="jenis_jamban" name="jenis_jamban" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['jenis_jamban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Jenis</option>
                            <option value="Saniter" <?php echo e(old('jenis_jamban', $keluarga->jenis_jamban) == 'Saniter' ? 'selected' : ''); ?>>Saniter</option>
                            <option value="Tidak_Saniter" <?php echo e(old('jenis_jamban', $keluarga->jenis_jamban) == 'Tidak_Saniter' ? 'selected' : ''); ?>>Tidak Saniter</option>
                        </select>
                        <?php $__errorArgs = ['jenis_jamban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Ventilasi -->
                    <div class="col-span-1">
                        <label for="ventilasi" class="block text-sm font-medium text-gray-700">Apakah rumah memiliki ventilasi yang cukup?</label>
                        <select id="ventilasi" name="ventilasi" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['ventilasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Status</option>
                            <option value="Ya" <?php echo e(old('ventilasi', $keluarga->ventilasi) == 'Ya' ? 'selected' : ''); ?>>Ya</option>
                            <option value="Tidak" <?php echo e(old('ventilasi', $keluarga->ventilasi) == 'Tidak' ? 'selected' : ''); ?>>Tidak</option>
                        </select>
                        <?php $__errorArgs = ['ventilasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Gangguan Jiwa -->
                    <div class="col-span-1">
                        <label for="gangguan_jiwa" class="block text-sm font-medium text-gray-700">Apakah ada anggota keluarga yang mengalami gangguan jiwa?</label>
                        <select id="gangguan_jiwa" name="gangguan_jiwa" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['gangguan_jiwa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Status</option>
                            <option value="Ya" <?php echo e(old('gangguan_jiwa', $keluarga->gangguan_jiwa) == 'Ya' ? 'selected' : ''); ?>>Ya</option>
                            <option value="Tidak" <?php echo e(old('gangguan_jiwa', $keluarga->gangguan_jiwa) == 'Tidak' ? 'selected' : ''); ?>>Tidak</option>
                        </select>
                        <?php $__errorArgs = ['gangguan_jiwa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Terdiagnosis Penyakit -->
                    <div class="col-span-1">
                        <label for="terdiagnosis_penyakit" class="block text-sm font-medium text-gray-700">Apakah ada anggota keluarga yang terdiagnosis penyakit berikut (TBC, Hipertensi, Diabetes Melitus)?</label>
                        <select id="terdiagnosis_penyakit" name="terdiagnosis_penyakit" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['terdiagnosis_penyakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option selected disabled>Pilih Status</option>
                            <option value="Ya" <?php echo e(old('terdiagnosis_penyakit', $keluarga->terdiagnosis_penyakit) == 'Ya' ? 'selected' : ''); ?>>Ya</option>
                            <option value="Tidak" <?php echo e(old('terdiagnosis_penyakit', $keluarga->terdiagnosis_penyakit) == 'Tidak' ? 'selected' : ''); ?>>Tidak</option>
                        </select>
                        <?php $__errorArgs = ['terdiagnosis_penyakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <input type="hidden" name="id_user" value="<?php echo e(auth()->user()->id); ?>"> <!-- Menyimpan ID user yang login -->

                <!-- Section for Anggota Keluarga -->
                <div class="bg-gray-100 rounded-lg p-4 mt-6">
                    <h3 class="text-md font-semibold text-gray-700">Data Anggota Keluarga</h3>
                    <div id="anggotaKeluargaContainer" class="mt-4 space-y-4">
                        
                        <!-- Dynamic anggota keluarga form fields will be inserted here -->
                        <?php $__currentLoopData = $keluarga->anggotaKeluarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-white rounded-md shadow-md">
                                <div class="col-span-2 flex justify-between items-center">
                                    <h5 class="font-semibold">Anggota Keluarga <?php echo e($index + 1); ?></h5>
                                    <button type="button" class="text-red-600 hover:text-red-800" onclick="removeAnggota(<?php echo e($index); ?>)">Hapus Anggota</button>
                                </div>

                              <!-- Nama Lengkap -->
                            <div class="col-span-1">
                                <label for="nama_lengkap_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">Nama Lengkap</label>
                                <input type="text" id="nama_lengkap_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][nama_lengkap]" value="<?php echo e(old('anggota.' . $index . '.nama_lengkap', $anggota->nama_lengkap)); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                                <?php $__errorArgs = ['anggota.' . $index . '.nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- NIK -->
                            <div class="col-span-1">
                                <label for="nik_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">NIK</label>
                                <input type="text" id="nik_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][nik]" value="<?php echo e($anggota->nik); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                                <!-- Pesan Error NIK -->
                                <?php $__errorArgs = ['anggota.' . $index . '.nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Tanggal Lahir -->
                            <div class="col-span-1">
                                <label for="tanggal_lahir_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">Tanggal Lahir</label>
                                <input type="date" id="tanggal_lahir_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][tanggal_lahir]" value="<?php echo e($anggota->tanggal_lahir); ?>" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                            </div>

                            <!-- Jenis Kelamin -->
                            <div class="col-span-1">
                                <label for="jenis_kelamin_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">Jenis Kelamin</label>
                                <select id="jenis_kelamin_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][jenis_kelamin]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                                    <option value="Laki-Laki" <?php echo e($anggota->jenis_kelamin === 'Laki-Laki' ? 'selected' : ''); ?>>Laki-Laki</option>
                                    <option value="Perempuan" <?php echo e($anggota->jenis_kelamin === 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                                </select>
                            </div>

                            <!-- Hubungan KK -->
                            <div class="col-span-1">
                                <label for="hubungan_kk_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">Hubungan KK</label>
                                <select id="hubungan_kk_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][hubungan_kk]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                                    <option value="1" <?php echo e($anggota->hubungan_kk == 1 ? 'selected' : ''); ?>>Kepala Keluarga</option>
                                    <option value="2" <?php echo e($anggota->hubungan_kk == 2 ? 'selected' : ''); ?>>Suami</option>
                                    <option value="3" <?php echo e($anggota->hubungan_kk == 3 ? 'selected' : ''); ?>>Istri</option>
                                    <option value="4" <?php echo e($anggota->hubungan_kk == 4 ? 'selected' : ''); ?>>Anak</option>
                                    <option value="5" <?php echo e($anggota->hubungan_kk == 5 ? 'selected' : ''); ?>>Menantu</option>
                                    <option value="6" <?php echo e($anggota->hubungan_kk == 6 ? 'selected' : ''); ?>>Cucu</option>
                                    <option value="7" <?php echo e($anggota->hubungan_kk == 7 ? 'selected' : ''); ?>>Orang Tua</option>
                                    <option value="8" <?php echo e($anggota->hubungan_kk == 8 ? 'selected' : ''); ?>>Mertua</option>
                                    <option value="9" <?php echo e($anggota->hubungan_kk == 9 ? 'selected' : ''); ?>>Anggota Lain</option>
                                </select>
                            </div>

                            <!-- Status Perkawinan -->
                            <div class="col-span-1">
                                <label for="status_perkawinan_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">Status Perkawinan</label>
                                <select id="status_perkawinan_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][status_perkawinan]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                                    <option value="1" <?php echo e($anggota->status_perkawinan == 1 ? 'selected' : ''); ?>>Belum Menikah</option>
                                    <option value="2" <?php echo e($anggota->status_perkawinan == 2 ? 'selected' : ''); ?>>Menikah</option>
                                    <option value="3" <?php echo e($anggota->status_perkawinan == 3 ? 'selected' : ''); ?>>Cerai Hidup</option>
                                    <option value="4" <?php echo e($anggota->status_perkawinan == 4 ? 'selected' : ''); ?>>Cerai Mati</option>
                                </select>
                            </div>

                            <!-- Pendidikan Terakhir -->
                            <div class="col-span-1">
                                <label for="pendidikan_terakhir_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">Pendidikan Terakhir</label>
                                <select id="pendidikan_terakhir_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][pendidikan_terakhir]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                                    <option value="1" <?php echo e($anggota->pendidikan_terakhir == 1 ? 'selected' : ''); ?>>Tidak Sekolah</option>
                                    <option value="2" <?php echo e($anggota->pendidikan_terakhir == 2 ? 'selected' : ''); ?>>SD</option>
                                    <option value="3" <?php echo e($anggota->pendidikan_terakhir == 3 ? 'selected' : ''); ?>>SMP</option>
                                    <option value="4" <?php echo e($anggota->pendidikan_terakhir == 4 ? 'selected' : ''); ?>>SMA</option>
                                    <option value="5" <?php echo e($anggota->pendidikan_terakhir == 5 ? 'selected' : ''); ?>>Diploma</option>
                                    <option value="6" <?php echo e($anggota->pendidikan_terakhir == 6 ? 'selected' : ''); ?>>Sarjana</option>
                                </select>
                            </div>

                            <!-- Pekerjaan -->
                            <div class="col-span-1">
                                <label for="pekerjaan_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">Pekerjaan</label>
                                <select id="pekerjaan_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][pekerjaan]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                                    <option value="1" <?php echo e($anggota->pekerjaan == 1 ? 'selected' : ''); ?>>Tidak Bekerja</option>
                                    <option value="2" <?php echo e($anggota->pekerjaan == 2 ? 'selected' : ''); ?>>Petani</option>
                                    <option value="3" <?php echo e($anggota->pekerjaan == 3 ? 'selected' : ''); ?>>PNS</option>
                                    <option value="4" <?php echo e($anggota->pekerjaan == 4 ? 'selected' : ''); ?>>Buruh</option>
                                    <option value="5" <?php echo e($anggota->pekerjaan == 5 ? 'selected' : ''); ?>>Wiraswasta</option>
                                    <option value="6" <?php echo e($anggota->pekerjaan == 6 ? 'selected' : ''); ?>>Pelajar</option>
                                    <option value="7" <?php echo e($anggota->pekerjaan == 7 ? 'selected' : ''); ?>>Lainnya</option>
                                </select>
                            </div>

                            <!-- Kelompok Sasaran -->
                            <div class="col-span-1">
                                <label for="kelompok_sasaran_<?php echo e($index); ?>" class="block text-sm font-medium text-gray-700">Kelompok Sasaran</label>
                                <select id="kelompok_sasaran_<?php echo e($index); ?>" name="anggota[<?php echo e($index); ?>][kelompok_sasaran]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                                    <option value="Ibu Hamil" <?php echo e($anggota->kelompok_sasaran == 'Ibu Hamil' ? 'selected' : ''); ?>>Ibu Hamil</option>
                                    <option value="Ibu Bersalin & Nifas" <?php echo e($anggota->kelompok_sasaran == 'Ibu Bersalin & Nifas' ? 'selected' : ''); ?>>Ibu Bersalin & Nifas</option>
                                    <option value="Bayi - Balita (0-6 bulan)" <?php echo e($anggota->kelompok_sasaran == 'Bayi - Balita (0-6 bulan)' ? 'selected' : ''); ?>>Bayi - Balita (0-6 bulan)</option>
                                    <option value="Balita dan Apras (6 - 71 bulan)" <?php echo e($anggota->kelompok_sasaran == 'Balita dan Apras (6 - 71 bulan)' ? 'selected' : ''); ?>>Balita dan Apras (6 - 71 bulan)</option>
                                    <option value="Usia Sekolah & Remaja" <?php echo e($anggota->kelompok_sasaran == 'Usia Sekolah & Remaja' ? 'selected' : ''); ?>>Usia Sekolah & Remaja</option>
                                    <option value="Usia Dewasa (18-59 tahun)" <?php echo e($anggota->kelompok_sasaran == 'Usia Dewasa (18-59 tahun)' ? 'selected' : ''); ?>>Usia Dewasa (18-59 tahun)</option>
                                    <option value="Lansia (≥60 tahun)" <?php echo e($anggota->kelompok_sasaran == 'Lansia (≥60 tahun)' ? 'selected' : ''); ?>>Lansia (≥60 tahun)</option>
                                </select>
                            </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <button type="button" id="addAnggotaButton" class="mt-3 inline-flex items-center px-4 py-2 border border-blue-600 rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Tambah Anggota
                    </button>
                </div>

                <div class="flex justify-end items-center mt-6 space-x-2">
                    <button type="submit" class="bg-gray-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded shadow">
                        Submit
                    </button>
                    <a href="<?php echo e(route('keluarga')); ?>" class="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded shadow text-center">
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Import jQuery for dynamic fields -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        let anggotaCount = <?php echo e(count($keluarga->anggotaKeluarga)); ?>;

        // Function to add new anggota keluarga form
        $('#addAnggotaButton').click(function() {
            anggotaCount++;
            let anggotaForm = `
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-white rounded-md shadow-md" id="anggota_${anggotaCount}">
                    <div class="col-span-2 flex justify-between items-center">
                        <h5 class="font-semibold">Anggota Keluarga ${anggotaCount}</h5>
                        <button type="button" class="text-red-600 hover:text-red-800" onclick="removeAnggota(${anggotaCount})">Hapus Anggota</button>
                    </div>
                    
                    <div class="col-span-1">
                        <label for="nama_lengkap_${anggotaCount}" class="block text-sm font-medium text-gray-700">Nama Lengkap</label>
                        <input type="text" id="nama_lengkap_${anggotaCount}" name="anggota[${anggotaCount}][nama_lengkap]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div class="col-span-1">
                        <label for="nik_${anggotaCount}" class="block text-sm font-medium text-gray-700">NIK</label>
                        <input type="text" id="nik_${anggotaCount}" name="anggota[${anggotaCount}][nik]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                        
                    </div>

                    <div class="col-span-1">
                        <label for="tanggal_lahir_${anggotaCount}" class="block text-sm font-medium text-gray-700">Tanggal Lahir</label>
                        <input type="date" id="tanggal_lahir_${anggotaCount}" name="anggota[${anggotaCount}][tanggal_lahir]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                    </div>

                    <div class="col-span-1">
                        <label for="jenis_kelamin_${anggotaCount}" class="block text-sm font-medium text-gray-700">Jenis Kelamin</label>
                        <select id="jenis_kelamin_${anggotaCount}" name="anggota[${anggotaCount}][jenis_kelamin]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="Laki-Laki">Laki-Laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>

                    <div class="col-span-1">
                        <label for="hubungan_kk_${anggotaCount}" class="block text-sm font-medium text-gray-700">Hubungan KK</label>
                        <select id="hubungan_kk_${anggotaCount}" name="anggota[${anggotaCount}][hubungan_kk]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="1">Kepala Keluarga</option>
                            <option value="2">Suami</option>
                            <option value="3">Istri</option>
                            <option value="4">Anak</option>
                            <option value="5">Menantu</option>
                            <option value="6">Cucu</option>
                            <option value="7">Orang Tua</option>
                            <option value="8">Mertua</option>
                            <option value="9">Anggota Lain</option>
                        </select>
                    </div>

                    <div class="col-span-1">
                        <label for="status_perkawinan_${anggotaCount}" class="block text-sm font-medium text-gray-700">Status Perkawinan</label>
                        <select id="status_perkawinan_${anggotaCount}" name="anggota[${anggotaCount}][status_perkawinan]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="1">Belum Menikah</option>
                            <option value="2">Menikah</option>
                            <option value="3">Cerai Hidup</option>
                            <option value="4">Cerai Mati</option>
                        </select>
                    </div>

                    <div class="col-span-1">
                        <label for="pendidikan_terakhir_${anggotaCount}" class="block text-sm font-medium text-gray-700">Pendidikan Terakhir</label>
                        <select id="pendidikan_terakhir_${anggotaCount}" name="anggota[${anggotaCount}][pendidikan_terakhir]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="1">Tidak Sekolah</option>
                            <option value="2">SD</option>
                            <option value="3">SMP</option>
                            <option value="4">SMA</option>
                            <option value="5">Diploma</option>
                            <option value="6">Sarjana</option>
                        </select>
                    </div>

                    <div class="col-span-1">
                        <label for="pekerjaan_${anggotaCount}" class="block text-sm font-medium text-gray-700">Pekerjaan</label>
                        <select id="pekerjaan_${anggotaCount}" name="anggota[${anggotaCount}][pekerjaan]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="1">Tidak Bekerja</option>
                            <option value="2">Petani</option>
                            <option value="3">PNS</option>
                            <option value="4">Buruh</option>
                            <option value="5">Wiraswasta</option>
                            <option value="6">Pelajar</option>
                            <option value="7">Lainnya</option>
                        </select>
                    </div>

                    <div class="col-span-1">
                        <label for="kelompok_sasaran_${anggotaCount}" class="block text-sm font-medium text-gray-700">Kelompok Sasaran</label>
                        <select id="kelompok_sasaran_${anggotaCount}" name="anggota[${anggotaCount}][kelompok_sasaran]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500" required>
                            <option value="Ibu Hamil">Ibu Hamil</option>
                            <option value="Ibu Bersalin & Nifas">Ibu Bersalin & Nifas</option>
                            <option value="Bayi - Balita (0-6 bulan)" <?php echo e($anggota->kelompok_sasaran == 'Bayi - Balita (0-6 bulan)' ? 'selected' : ''); ?>>Bayi - Balita (0-6 bulan)</option>
                            <option value="Balita dan Apras (6 - 71 bulan)" <?php echo e($anggota->kelompok_sasaran == 'Balita dan Apras (6 - 71 bulan)' ? 'selected' : ''); ?>>Balita dan Apras (6 - 71 bulan)</option>
                            <option value="Usia Sekolah & Remaja">Usia Sekolah & Remaja</option>
                            <option value="Usia Dewasa (18-59 tahun)">Usia Dewasa (18-59 tahun)</option>
                            <option value="Lansia (≥60 tahun)">Lansia (≥60 tahun)</option>
                        </select>
                    </div>
                </div>`; 
            
            $('#anggotaKeluargaContainer').append(anggotaForm);
        });

        // Function to remove anggota keluarga form
        window.removeAnggota = function(anggotaId) {
            $('#anggota_' + anggotaId).remove();
        };
    });
</script>
<script>
    const kelurahanOptions = {
        'Banjarsari': [
            'Banjarsari', 'Banyuanyar', 'Gilingan', 'Joglo', 'Kadipiro',
            'Keprabon', 'Kestalan', 'Ketelan', 'Manahan', 'Mangkubumen',
            'Nusukan', 'Punggawan', 'Setabelan', 'Sumber Timuran'
        ],
        'Jebres': [
            'Gandekan', 'Jagalan', 'Jebres', 'Kepatihan Kulon', 'Kepatihan Wetan',
            'Mojosongo', 'Pucang Sawit', 'Purwodiningratan', 'Sewu',
            'Sudiroprajan', 'Tegalharjo'
        ],
        'Laweyan': [
            'Bumi', 'Jajar', 'Karangasem', 'Kerten', 'Laweyan', 'Pajang',
            'Panularan', 'Penumping', 'Purwosari', 'Sondakan', 'Sriwedari'
        ],
        'Pasar Kliwon': [
            'Baluwarti', 'Gajahan', 'Joyosuran', 'Kampung Baru', 'Kauman',
            'Kedung Lumbu', 'Mojo', 'Pasar Kliwon', 'Sangkrah', 'Semanggi'
        ],
        'Serengan': [
            'Danukusuman', 'Jayengan', 'Joyotakan', 'Kemlayan', 'Kratonan',
            'Serengan', 'Tipes'
        ]
    };

    $(document).ready(function() {
        // Trigger population of Kelurahan based on selected Kecamatan
        $('#kecamatan').on('change', function() {
            var kecamatan = $(this).val();
            var kelurahanDropdown = $('#kelurahan');
            kelurahanDropdown.empty().append('<option selected disabled>Pilih Kelurahan</option>');

            if (kecamatan && kelurahanOptions[kecamatan]) {
                kelurahanOptions[kecamatan].forEach(function(kelurahan) {
                    kelurahanDropdown.append('<option value="' + kelurahan + '">' + kelurahan + '</option>');
                });
            }
        });

        // Set the initial selected value of Kelurahan if available
        var initialKelurahan = '<?php echo e($keluarga->kelurahan); ?>'; // Assuming `kelurahan` is a property
        if (initialKelurahan) {
            $('#kecamatan').val('<?php echo e($keluarga->kecamatan); ?>').trigger('change'); // Trigger change to load Kelurahan options
            $('#kelurahan').val(initialKelurahan); // Set the selected Kelurahan
        }
    });
</script>

<!-- Tambahkan Script SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Cek jika ada pesan sukses di session
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: '<?php echo e(session('success')); ?>',
            });
        <?php endif; ?>

        // Cek jika ada pesan error di session
        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: '<?php echo e(session('error')); ?>',
            });
        <?php endif; ?>
    });
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/keluarga/edit.blade.php ENDPATH**/ ?>