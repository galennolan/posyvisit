<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Edit Kader Posyandu')); ?>

            </h2>
            <nav class="breadcrumb">
                <ol class="list-reset flex text-sm"> <!-- Perkecil font dengan text-sm -->
                    <li><a href="/admin/users" class="text-blue-600 hover:text-blue-800">Daftar Kader </a></li>
                    <li><span class="mx-2">/ </span></li>
                    <!-- Tambahkan warna biru pada item yang dikunjungi -->
                    <li class="text-blue-600 font-semibold"> Edit</li> 
                </ol>
            </nav>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <!-- Notifikasi berhasil -->
                    <?php if(session('success')): ?>
                        <div class="bg-green-500 text-white p-4 mb-4 rounded-lg">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Form Edit User -->
                    <form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Nama -->
                        <div class="mb-4">
                            <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Nama</label>
                            <input type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>" class="mt-1 block w-full rounded-md shadow-sm dark:bg-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Email -->
                        <div class="mb-4">
                            <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
                            <input type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" class="mt-1 block w-full rounded-md shadow-sm dark:bg-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" required>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Role -->
                        <div class="mb-4">
                            <label for="role" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Role</label>
                            <select name="role" id="role" class="mt-1 block w-full rounded-md shadow-sm dark:bg-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->name); ?>" <?php echo e($user->roles->pluck('name')->contains($role->name) ? 'selected' : ''); ?>>
                                        <?php echo e($role->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Kecamatan -->
                        <div class="mb-4">
                            <label for="kecamatan" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Kecamatan</label>
                            <select name="kecamatan" id="kecamatan" class="mt-1 block w-full rounded-md shadow-sm dark:bg-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                <option value="">Pilih Kecamatan</option>
                                <option value="Banjarsari" <?php echo e(old('kecamatan', $user->kecamatan) == 'Banjarsari' ? 'selected' : ''); ?>>Banjarsari</option>
                                <option value="Jebres" <?php echo e(old('kecamatan', $user->kecamatan) == 'Jebres' ? 'selected' : ''); ?>>Jebres</option>
                                <option value="Laweyan" <?php echo e(old('kecamatan', $user->kecamatan) == 'Laweyan' ? 'selected' : ''); ?>>Laweyan</option>
                                <option value="Pasar Kliwon" <?php echo e(old('kecamatan', $user->kecamatan) == 'Pasar Kliwon' ? 'selected' : ''); ?>>Pasar Kliwon</option>
                                <option value="Serengan" <?php echo e(old('kecamatan', $user->kecamatan) == 'Serengan' ? 'selected' : ''); ?>>Serengan</option>
                            </select>
                            <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Kelurahan -->
                        <div class="mb-4">
                            <label for="kelurahan" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Kelurahan</label>
                            <select name="kelurahan" id="kelurahan" class="mt-1 block w-full rounded-md shadow-sm dark:bg-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                <option value="">Pilih Kelurahan</option>
                                <!-- Kelurahan akan diisi oleh JavaScript -->
                            </select>
                            <?php $__errorArgs = ['kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Nama Posyandu -->
                        <div class="mb-4">
                            <label for="nama_posyandu" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Nama Posyandu</label>
                            <input type="text" name="nama_posyandu" id="nama_posyandu" value="<?php echo e(old('nama_posyandu', $user->nama_posyandu)); ?>" class="mt-1 block w-full rounded-md shadow-sm dark:bg-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" required>
                            <?php $__errorArgs = ['nama_posyandu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-sm"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Tombol Simpan -->
                        <div class="flex justify-end">
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="bg-red-500 text-white px-4 py-2 rounded-lg mr-2 hover:bg-gray-600">Batal</a>
                            <button type="submit" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">Simpan Perubahan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Script untuk dynamic dropdown Kelurahan -->
    <script>
        const kelurahanOptions = {
            'Banjarsari': [
                'Banjarsari', 'Banyuanyar', 'Gilingan', 'Joglo', 'Kadipiro', 'Keprabon', 'Kestalan', 'Ketelan', 'Manahan', 'Mangkubumen', 'Nusukan', 'Punggawan', 'Setabelan', 'Sumber Timuran'
            ],
            'Jebres': [
                'Gandekan', 'Jagalan', 'Jebres', 'Kepatihan Kulon', 'Kepatihan Wetan', 'Mojosongo', 'Pucang Sawit', 'Purwodiningratan', 'Sewu', 'Sudiroprajan', 'Tegalharjo'
            ],
            'Laweyan': [
                'Bumi', 'Jajar', 'Karangasem', 'Kerten', 'Laweyan', 'Pajang', 'Panularan', 'Penumping', 'Purwosari', 'Sondakan', 'Sriwedari'
            ],
            'Pasar Kliwon': [
                'Baluwarti', 'Gajahan', 'Joyosuran', 'Kampung Baru', 'Kauman', 'Kedung Lumbu', 'Mojo', 'Pasar Kliwon', 'Sangkrah', 'Semanggi'
            ],
            'Serengan': [
                'Danukusuman', 'Jayengan', 'Joyotakan', 'Kemlayan', 'Kratonan', 'Serengan', 'Tipes'
            ]
        };

        document.getElementById('kecamatan').addEventListener('change', function() {
            const kelurahanSelect = document.getElementById('kelurahan');
            kelurahanSelect.innerHTML = '<option value="">Pilih Kelurahan</option>'; // Clear existing options
            const selectedKecamatan = this.value;
            if (kelurahanOptions[selectedKecamatan]) {
                kelurahanOptions[selectedKecamatan].forEach(function(kelurahan) {
                    const option = document.createElement('option');
                    option.value = kelurahan;
                    option.textContent = kelurahan;
                    kelurahanSelect.appendChild(option);
                });
            }
        });

        // Set Kelurahan saat halaman di-load jika ada kecamatan yang sudah dipilih
        document.addEventListener('DOMContentLoaded', function() {
            const kecamatan = document.getElementById('kecamatan').value;
            const kelurahan = "<?php echo e(old('kelurahan', $user->kelurahan)); ?>"; // Ambil kelurahan yang dipilih user
            if (kecamatan && kelurahanOptions[kecamatan]) {
                const kelurahanSelect = document.getElementById('kelurahan');
                kelurahanOptions[kecamatan].forEach(function(kelurahanName) {
                    const option = document.createElement('option');
                    option.value = kelurahanName;
                    option.textContent = kelurahanName;
                    if (kelurahanName === kelurahan) {
                        option.selected = true;
                    }
                    kelurahanSelect.appendChild(option);
                });
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\posyvisit\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>